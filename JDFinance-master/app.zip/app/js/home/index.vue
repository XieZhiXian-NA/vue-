<template lang="html">
    <div >
        <Heador/>
        <Hslider/>
    </div>
</template>

<script>
import Heador from "../public/header.vue"
import Hslider from "./hslider.vue"
export default {
    components: {
        Heador,
        Hslider,
    },
}
</script>

<style lang="scss" module>
 @import '../../css/reset.scss'
</style>
