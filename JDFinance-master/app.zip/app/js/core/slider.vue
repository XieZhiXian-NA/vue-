<template>
    <section :class="cname">
        <swiper :options="options"
                :auto-update="true"
                :auto-destroy="true"
                :delete-instance-on-destroy="true"
                :cleanup-styles-on-destroy="true"
                @ready="handleSwiperReadied"
                @click-slide="handleClickSlide"
        >
            <swiper-slide v-for="item in items" :key="item.src">
                <router-link :to="{name:item.href}">
                    <img :src="item.src" alt=" ">
                </router-link>
            </swiper-slide>
            <div class="swiper-pagination" v-if="options.pagination"/>
        </swiper>
    </section>
</template>

<script>
import { Swiper, SwiperSlide } from "vue-awesome-swiper"

export default {
    props: {
        options: {
            type: Object,
            default() {
                return ({
                    autoplay: true,
                    loop: true,
                    pagination: {
                        el: ".swiper-pagination",
                    },
                })
            },
        },
        items: {
            type: Array,
            default() {
                return [
                    { href: "", src: "" },
                ]
            },
        },
        cname: {
            type: String,
            default: "",
        },
    },
    data() {
        return {
        }
    },
    components: {
        Swiper,
        SwiperSlide,
    },
    methods: {
        handleSwiperReadied() {

        },
        handleClickSlide() {

        },
        updateSwiper() {

        },
        destroySwiper() {

        },
        initSwiper() {

        },
    },
}
</script>

<style lang="css" scoped>
@import "~swiper/css/swiper.css";
</style>
